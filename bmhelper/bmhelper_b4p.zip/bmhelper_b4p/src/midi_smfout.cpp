
#include "midi_data.h"
#include "smf_io.h"
#include <wx/file.h>


bool MidiData::save_smf(const wxString &filename) const{

	SmfData smf(quantize);

	// �g���b�N0
	{
		SmfDataAccessor track(smf, 0);
		track.EndOfTrack(-1);
	}
	// �g���b�N1
	{
		SmfDataAccessor track(smf, 1);
		for (size_t i=0; i<note_events.size(); i++){
			track.Note(note_events[i].position, 0, note_events[i].gate, note_events[i].note_num, note_events[i].velocity);
		}
		for (size_t i=0; i<pb_events.size(); i++){
			track.PitchBend(pb_events[i].position, 0, pb_events[i].value);
		}
		for (MidiCCLanesMap::const_iterator it=cc_lanes.begin(); it!=cc_lanes.end(); it++){
			int ccn = it->first;
			const MidiParamsLane &lane = it->second;
			for (size_t i=0; i<lane.size(); i++){
				track.ControlChange(lane[i].position, 0, ccn, lane[i].value);
			}
		}
		track.EndOfTrack(-1);
	}
	if (!smf.save(filename)) return false;

	return true;
}




