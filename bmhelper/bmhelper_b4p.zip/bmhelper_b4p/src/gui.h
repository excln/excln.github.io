
#pragma once

#include "common.h"



DECLARE_EVENT_TYPE(wxEVT_SET_STATUS_TEXT, -1)





