
#include "app.h"


#ifdef _DEBUG

#pragma comment(lib, "wxmsw28d_core.lib")
#pragma comment(lib, "wxbase28d.lib")
#pragma comment(lib, "wxtiffd.lib")
#pragma comment(lib, "wxjpegd.lib")
#pragma comment(lib, "wxpngd.lib")
#pragma comment(lib, "wxzlibd.lib")
#pragma comment(lib, "wxregexd.lib")
#pragma comment(lib, "wxexpatd.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "wsock32.lib")
#pragma comment(lib, "odbc32.lib")

#else

#pragma comment(lib, "wxmsw28_core.lib")
#pragma comment(lib, "wxbase28.lib")
#pragma comment(lib, "wxtiff.lib")
#pragma comment(lib, "wxjpeg.lib")
#pragma comment(lib, "wxpng.lib")
#pragma comment(lib, "wxzlib.lib")
#pragma comment(lib, "wxregex.lib")
#pragma comment(lib, "wxexpat.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "wsock32.lib")
#pragma comment(lib, "odbc32.lib")

#endif



wxString app_name(_("Be-Music Helper"));
wxString app_version(_("beta 4\'"));


bool Application::OnInit(){
	FrameWindow *frame = new FrameWindow(wxPoint(wxDefaultCoord, wxDefaultCoord), wxSize(640, 480));
	frame->OpenFiles(argc-1, &argv[1]);
	this->SetTopWindow(frame);
	frame->Show();
	return true;
}



IMPLEMENT_APP(Application)


