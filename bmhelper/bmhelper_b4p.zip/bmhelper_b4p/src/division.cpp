
#include "division.h"
#include "project.h"
#include <algorithm>
#include <map>
#include <wx/xml/xml.h>

/*
	�N�b�\�����̈��������̎d�����Ă邯�ǁA���ꂭ�炢�̃f�[�^�ʂȂ���v�ł���
	�C�ɂȂ�ɐl��������K���ɉ��ǂ��Ă���
*/


struct ThresholdSetting{
	int gate;
	int vel;
};
struct BasicNote{
	int nn;
	int gate;
	int vel;
	bool accepts(const BasicNote &note, const ThresholdSetting &thresholds) const{
		return (nn==note.nn) && (abs(gate-note.gate)<=thresholds.gate) && (abs(vel-note.vel)<=thresholds.vel);
	}
};
struct IndexedNote : public BasicNote{
	int index;
	bool operator >(const IndexedNote &r) const{
		return nn==r.nn ? (gate==r.gate? vel>r.vel : gate>r.gate) : nn>r.nn;
	}
	bool operator <(const IndexedNote &r) const{
		return nn==r.nn ? (gate==r.gate? vel<r.vel : gate<r.gate) : nn<r.nn;
	}
};
struct ReferredNote : public BasicNote{
	std::vector<int> referrers;
};

class NotesCluster{
	std::vector<IndexedNote> notes;
	static bool ByGate(const IndexedNote &l, const IndexedNote &r){	// ��r(<)
		return l.gate < r.gate;
	}
	static bool ByVel(const IndexedNote &l, const IndexedNote &r){	// ��r(<)
		return l.vel < r.vel;
	}
public:
	NotesCluster(){}
	NotesCluster(const IndexedNote &note) : notes(1, note){}
	bool accept(const IndexedNote &note, const ThresholdSetting &thresholds){
		for (std::vector<IndexedNote>::iterator i=notes.begin(); i!=notes.end(); i++){
			if (i->accepts(note, thresholds)){
				notes.push_back(note);
				return true;
			}
		}
		return false;
	}
	void divide(std::vector<int> &src2div, std::vector<ReferredNote> &divs, const ThresholdSetting &thresholds){
		int gate_min = min_element(notes.begin(), notes.end(), ByGate)->gate;
		int gate_max = max_element(notes.begin(), notes.end(), ByGate)->gate+1;
		int vel_min = min_element(notes.begin(), notes.end(), ByVel)->vel;
		int vel_max = max_element(notes.begin(), notes.end(), ByVel)->vel+1;
		int gate_div = (gate_max-gate_min+thresholds.gate)/(thresholds.gate+1);
		int vel_div = (vel_max-vel_min+thresholds.vel)/(thresholds.vel+1);
		int gt = gate_min, gt_nxt;
		for (int ig=0; ig<gate_div; ig++){
			gt_nxt = gate_min + (ig+1)*abs(gate_max-gate_min)/gate_div;
			int vl = vel_min, vl_nxt;
			for (int iv=0; iv<vel_div; iv++){
				vl_nxt = vel_min + (iv+1)*abs(vel_max-vel_min)/vel_div;
				int c=0;
				int div_index = divs.size();
				ReferredNote div_note;
				div_note.nn = 0;
				div_note.gate = 0;
				div_note.vel = 0;
				for (size_t in=0; in<notes.size(); in++){
					if (notes[in].gate >= gt && notes[in].gate < gt_nxt && notes[in].vel >= vl && notes[in].vel < vl_nxt){
						src2div[notes[in].index] = div_index;
						div_note.referrers.push_back(notes[in].index);
						div_note.nn += notes[in].nn;
						div_note.gate += notes[in].gate;
						div_note.vel += notes[in].vel;
						c++;
					}
				}
				if (c){
					div_note.nn /= c;
					div_note.gate /= c;
					div_note.vel /= c;
					divs.push_back(div_note);
				}
				vl = vl_nxt;
			}
			gt = gt_nxt;
		}
	}
};

typedef int (*CompareNoteFunc)(const ReferredNote&, const ReferredNote&);

static int CompareNote_N_Asc(const ReferredNote &l, const ReferredNote &r){
	return l.nn-r.nn;
}
static int CompareNote_G_Desc(const ReferredNote &l, const ReferredNote &r){
	return r.gate-l.gate;
}
static int CompareNote_V_Desc(const ReferredNote &l, const ReferredNote &r){
	return r.vel-l.vel;
}

#define COMPARE_NOTE(fa, l, r) \
	((((fa)[0](l,r))? ((fa)[0](l,r)) : ( ((fa)[1](l,r))? ((fa)[1](l,r)) : ((fa)[2](l,r)) ) )>0)

Division::Division(Project *_project) : project(_project)
{}

static void _divide_notes(
	MidiData &src,
	std::vector<int> &src2div,
	std::vector<ReferredNote> &temp_divs,
	ThresholdSetting &thresholds
	)
{
	std::vector<NotesCluster> clusters;
	for (size_t i=0; i!=src.notes_count(); i++){
		IndexedNote note;
		note.index = i;
		note.nn = src.notes(i).note_num;
		note.gate = src.notes(i).gate;
		note.vel = src.notes(i).velocity;
		bool accepted = false;
		for (std::vector<NotesCluster>::iterator ic=clusters.begin(); ic!=clusters.end(); ic++){
			if (ic->accept(note, thresholds)){
				accepted = true;
				break;
			}
		}
		if (!accepted){
			clusters.push_back(NotesCluster(note));
		}
	}
	for (std::vector<NotesCluster>::iterator i=clusters.begin(); i!=clusters.end(); i++){
		i->divide(src2div, temp_divs, thresholds);
	}
}

static void _sort_notes(
	std::vector<ReferredNote> &temp_divs,
	std::vector<int> &src2div,
	DivisionSetting::SortType sort_type
	)
{
	if (sort_type == DivisionSetting::SORT_NONE) return;
	CompareNoteFunc faa[][3] = {
		{ CompareNote_N_Asc, CompareNote_G_Desc, CompareNote_V_Desc },
		{ CompareNote_N_Asc, CompareNote_V_Desc, CompareNote_G_Desc },
		{ CompareNote_G_Desc, CompareNote_N_Asc, CompareNote_V_Desc },
		{ CompareNote_G_Desc, CompareNote_V_Desc, CompareNote_N_Asc },
		{ CompareNote_V_Desc, CompareNote_N_Asc, CompareNote_G_Desc },
		{ CompareNote_V_Desc, CompareNote_G_Desc, CompareNote_N_Asc },
	};
	CompareNoteFunc *fa = faa[(int)sort_type-1];
	for (size_t i1=0; i1<temp_divs.size()-1; i1++){
		for (size_t i2=i1+1; i2<temp_divs.size(); i2++){
			if (COMPARE_NOTE(fa, temp_divs[i1], temp_divs[i2])){
				ReferredNote note = temp_divs[i1]; temp_divs[i1] = temp_divs[i2]; temp_divs[i2] = note;
				for (size_t ir=0; ir<temp_divs[i1].referrers.size(); ir++) src2div[temp_divs[i1].referrers[ir]] = i1;
				for (size_t ir=0; ir<temp_divs[i2].referrers.size(); ir++) src2div[temp_divs[i2].referrers[ir]] = i2;
			}
		}
	}
}

Division::Division(Project *_project, MidiData &src, const DivisionSetting &setting)
	: MidiData(src.get_quantize()), project(_project), name(setting.name), zz_enabled(setting.zz_definition)
{
	std::vector<ReferredNote> temp_divs;
	std::vector<int> src2div(src.notes_count());
	src2def.resize(src.notes_count());

	if (setting.src_copy){
		// src��temp_divs�ɃR�s�[
		temp_divs.resize(src.notes_count());
		for (size_t i=0; i!=src.notes_count(); i++){
			ReferredNote &note = temp_divs[i];
			note.nn = src.notes(i).note_num;
			note.gate = src.notes(i).gate;
			note.vel = src.notes(i).velocity;
			note.referrers.push_back(i);
			src2div[i] = i;
		}
		// Midi�f�[�^�ɂ��̂܂ܔz�u
		for (size_t i=0; i<temp_divs.size(); i++){
			note_push_back(MidiNoteEvent(src.notes(i).position+setting.head_margin, temp_divs[i].gate, temp_divs[i].nn, temp_divs[i].vel));
		}
		if (src.notes_count() > 0) head_margin = src.notes(0).position+setting.head_margin;
	}else{
		// ����
		ThresholdSetting thresholds;
		thresholds.gate = setting.gate_threshold;
		thresholds.vel  = setting.velocity_threshold;
		_divide_notes(src, src2div, temp_divs, thresholds);
		// �\�[�g
		_sort_notes(temp_divs, src2div, setting.sort_type);
		// Midi�f�[�^�ɗ�������
		int position = setting.head_margin;
		for (size_t i=0; i<temp_divs.size(); i++){
			note_push_back(MidiNoteEvent(position, temp_divs[i].gate, temp_divs[i].nn, temp_divs[i].vel));
			position += setting.min_interval + temp_divs[i].gate;
			int b = position % get_quantize();
			if (b) position += get_quantize() - b;
		}
		head_margin = setting.head_margin;
	}

	// ��`�̍쐬(���d��`�������ꍇ��div��1��1�Ή�)
	ZZNumber zz = setting.start_definition;
	if (!setting.zz_definition) if (!zz.in_ff()) zz.increment_in_ff();
	for (size_t i=0; i<temp_divs.size(); i++){
		// �K�v�Ȓ�`���𒲂ׂ�
		size_t mln;
		if (setting.ml_definition){
			for (mln=1; mln<=temp_divs[i].referrers.size(); mln++){
				int mint = INT_MAX;
				for (size_t b=0; b<mln; b++){
					int pos = src.notes(temp_divs[i].referrers[b]).position;
					int end = pos + src.notes(temp_divs[i].referrers[b]).gate;
					for (size_t ir=b; ir<temp_divs[i].referrers.size()-mln; ir+=mln){
						int next_pos = src.notes(temp_divs[i].referrers[ir+mln]).position;
						int next_end = next_pos + src.notes(temp_divs[i].referrers[ir+mln]).gate;
						if (next_pos - end < mint){
							mint = next_pos - end;
						}
						pos = next_pos;
						end = next_end;
					}
				}
				if (mint >= setting.ml_threshold) break;
			}
		}else{
			mln = 1;	// ���d��`���Ȃ�
		}
		size_t id_i = definitions.size();
		for (size_t b=0; b<mln; b++){
			definitions.push_back(Definition(zz, i));
			if (setting.zz_definition) zz++; else zz.increment_in_ff();
		}
		size_t b=0;
		for (size_t ir=0; ir<temp_divs[i].referrers.size(); ir++){
			src2def[temp_divs[i].referrers[ir]] = id_i+b;
			if (++b == mln) b=0;
		}
	}

}



void Division::def_transpose_up(){
	//if (definitions.begin()->zz == ZZNumber(1)) return;
	if (zz_enabled){
		for (size_t i=0; i<definitions.size(); i++){
			definitions[i].zz--;
		}
	}else{
		for (size_t i=0; i<definitions.size(); i++){
			definitions[i].zz.decrement_in_ff();
		}
	}
}

void Division::def_transpose_down(){
	if (zz_enabled){
		//if (definitions.back().zz == ZZNumber(35,35)) return;
		for (size_t i=0; i<definitions.size(); i++){
			definitions[i].zz++;
		}
	}else{
		//if (definitions.back().zz == ZZNumber(15,15)) return;
		for (size_t i=0; i<definitions.size(); i++){
			definitions[i].zz.increment_in_ff();
		}
	}
}

void Division::def_transpose_to(ZZNumber nbegin){
	if (definitions.empty()) return;
	if (zz_enabled){
		int diff = int(nbegin) - int(definitions[0].zz);
		for (size_t i=0; i<definitions.size(); i++){
			int tmp = int(definitions[i].zz) + diff;
			if (tmp < 0) tmp += 36*36;
			if (tmp >= 36*36) tmp -= 36*36;
			definitions[i].zz = (unsigned)tmp;
		}
	}else{
		// �߂�ǂ��̂ŏ_��̂Ȃ���������
		for (size_t i=0; i<definitions.size(); i++){
			definitions[i].zz = nbegin;
			nbegin.increment_in_ff();
		}
	}
}


//////////////////////////////////////////////////////////////////////////////
//
//	�R�s�y�p�V�[�P���X�f�[�^�̍쐬

static const size_t bmse_quantize = 192/4;

wxString Division::get_div_sequence_data() const{
	wxString data(_("BMSE ClipBoard Object Data Format\r\n"));
	for (size_t i=0; i<notes_count(); i++){
		data += wxString::Format(_("011%08d1\r\n"), notes(i).position*bmse_quantize/get_quantize());
	}
	return data;
}


wxString Division::get_bms_sequence_data(const MidiData &src) const{
	wxString data(_("BMSE ClipBoard Object Data Format\r\n"));
	int lane;
	std::map<int, int> lanes;
	for (size_t i=0; i<src.notes_count(); i++){
		ZZNumber zz = definitions[src2def[i]].zz;
		int position = src.notes(i).position*bmse_quantize/get_quantize();
		if (lanes.find(position) == lanes.end()){
			lane = lanes[position] = 1;
		}else{
			lane = ++lanes[position];
		}
		unsigned int t = static_cast<unsigned int>(zz);
		data += wxString::Format(_("1%02d%08d%d\r\n"), lane, position, t);
	}
	return data;
}




//////////////////////////////////////////////////////////////////////////////
//
//	Tree IO

static const NodeName _Midi_ = StringToNodeName("Midi");
static const NodeName _name_ = StringToNodeName("name");
static const NodeName _s2df_ = StringToNodeName("s2df");
static const NodeName _dfnt_ = StringToNodeName("dfnt");

bool Division::read_tree(TreeNode &node){
	init();
	for (TreeNode::iterator sub=node.begin(); sub!=node.end(); sub++){
		if (sub->get_name() == _Midi_){
			if (!MidiData::read_tree(*sub)) return false;
		}else if (sub->get_name() == _name_){
			char *temp = new char[sub->get_data_size()+1];
			if (sub->get_data_size()) sub->get_data(temp, sub->get_data_size());
			temp[sub->get_data_size()] = '\0';
			name = temp;
		}else if (sub->get_name() == _s2df_){
			size_t size = sub->get_data_size() / sizeof(int);
			src2def.resize(size);
			int *temp = new int[size+1];
			sub->get_data(temp, (size+1)*(sizeof(int)));
			for (size_t i=0; i<size; i++) src2def[i] = temp[i];
			delete[] temp;
		}else if (sub->get_name() == _dfnt_){
			Definition d;
			if (sub->get_data_size() == sizeof(Definition)){
				sub->get_data(&d, sizeof(Definition));
				definitions.push_back(d);
			}
		}
	}
	return true;
}


bool Division::write_tree(TreeNode &node){
	node.push_back(_Midi_);
	if (!MidiData::write_tree(node.back())) return false;
	node.push_back(_name_);
	node.back().set_data(name.GetData(), name.size());
	{
		node.push_back(_s2df_);
		int *temp = new int[src2def.size()];
		for (size_t i=0; i<src2def.size(); i++) temp[i] = src2def[i];
		node.back().set_data(temp, src2def.size()*(sizeof(int)));
		delete[] temp;
	}
	for (DefinitionsVector::iterator i=definitions.begin(); i!=definitions.end(); i++){
		node.push_back(_dfnt_);
		node.back().set_data(&(*i), sizeof(Definition));
	}
	return true;
}



