
#pragma once

#include "common.h"
#include "frame.h"


class Application : public wxApp{
public:
	virtual bool OnInit();
};


