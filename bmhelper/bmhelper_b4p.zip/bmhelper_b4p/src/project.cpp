
#include "project.h"
#include <wx/xml/xml.h>

wxString project_file_ext(_("bmh"));
wxString midi_file_filter(_("MIDI�t�@�C��(*.mid;*.midi;*.smf)|*.mid;*.midi;*.smf"));
wxString project_file_filter = wxString(_("BMHelper�v���W�F�N�g�t�@�C��(*.bmh)|*.bmh"));



Project::Project(const wxString &_filename)
: titled(false), changed(false), observer(0)
{
	wxFileName fn(_filename);
	wxString ext = fn.GetExt();
	if (!ext.CmpNoCase(_("mid")) || !ext.CmpNoCase(_("midi")) || !ext.CmpNoCase(_("smf")) ){
		// midi�t�@�C������V�K�v���W�F�N�g�쐬
		titled = false;
		changed = true;
		if (!source.load_smf(_filename)){
			throw 0;
		}
		filename = fn;
		filename.SetExt(project_file_ext);
	}else if (!ext.CmpNoCase(project_file_ext)){
		// �����̃v���W�F�N�g���J��
		filename = _filename;
		titled = true;
		changed = false;
		TreeDocument document;
		document.load(_filename);
		if (!read_tree(document.get_root())) throw 0;
	}else{
		// ���m�̊g���q
		throw 0;
	}
}

Project::~Project(){
	ClearDivisions();
}

void Project::init(){
	ClearDivisions();
}

void Project::SetChangeFlag(bool f){
	if (changed != f){
		changed = f;
		if (observer) observer->ProjectChangeFlagChanged();
	}
}

bool Project::Titled() const{
	return titled;
}

bool Project::Changed() const{
	return changed;
}

bool Project::Save(){
	if (!titled) return false;
	{
		TreeDocument document;
		if (!write_tree(document.get_root())) return false;
		document.save(filename.GetFullPath());
	}
	SetChangeFlag(false);
	return true;
}

bool Project::SaveAs(const wxString &_new_filename){
	filename = wxFileName(_new_filename);
	titled = true;
	bool bRet = Save();
	if (observer) observer->ProjectFileNameChanged();
	return bRet;
}



ProjectObserver *Project::SetObserver(ProjectObserver *new_obs){
	ProjectObserver *old = observer;
	observer = new_obs;
	return old;
}

wxString Project::GetFileName() const{
	return filename.GetFullPath();
}

wxString Project::GetFileTitle() const{
	return filename.GetFullName();
}

wxString Project::GetTitle() const{
	return filename.GetName();
}


void Project::ClearDivisions(){
	if (!divisions.size()) return;
	for (size_t i=0; i<divisions.size(); i++){
		delete divisions[i];
	}
	divisions.clear();
	changed = true;
}

size_t Project::CreateDivision(const DivisionSetting &setting){
	size_t n = divisions.size();
	Division *div = new Division(this, source, setting);
	divisions.push_back(div);
	SetChangeFlag(true);
	return n;
}

void Project::EraseDivision(size_t index){
	int n=0;
	for (DivisionsVector::iterator i=divisions.begin(); i!=divisions.end(); i++,n++){
		if (n==index){
			delete *i;
			divisions.erase(i);
			SetChangeFlag(true);
			break;
		}
	}
}

//-----------------------------------------------------------------------


static const NodeName _BMHP_ = StringToNodeName("BMHP");
static const NodeName _Src_  = StringToNodeName("Src ");
static const NodeName _Div_  = StringToNodeName("Div ");


bool Project::read_tree(TreeNode &node){
	try{
		if (node.get_name() != _BMHP_) throw 0;
		for (TreeNode::iterator i=node.begin(); i!=node.end(); i++){
			if (i->get_name() == _Src_){
				if (!source.read_tree(*i)) throw 1;
			}else if (i->get_name() == _Div_){
				divisions.push_back(new Division(this));
				Division *div = divisions.back();
				if (!div->read_tree(*i)) throw 2;
			}
		}
	}catch(...){
		return false;
	}
	return true;
}

bool Project::write_tree(TreeNode &node){
	try{
		node.set_name(_BMHP_);
		node.push_back(TreeNode(_Src_));
		if (!source.write_tree(node.back())) throw 0;
		for (DivisionsVector::iterator i=divisions.begin(); i!=divisions.end(); i++){
			node.push_back(TreeNode(_Div_));
			if (!(*i)->write_tree(node.back())) throw 1;
		}
	}catch(...){
		return false;
	}
	return true;
}




